package com.example.administrator.handlermessagedemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.lang.ref.WeakReference;

@SuppressWarnings("unused")
public class MainActivity extends AppCompatActivity {
    public TextView tvResult;
    public Button btnDownload;
    private static final int DOWN_LOADING = 0;
    private static final int DOWN_FAILED = 1;
    private static final int DOWN_FINISH = 2;
    private boolean isDownloading = false;
    private MyHandler myHandler;

    /**
     * 静态内部类不会持有对外部类的引用
     * 内部使用WeakReference持有外部的引用
     */
    static class MyHandler extends Handler {
        private WeakReference<Activity> weakReference;
        MyHandler(Activity activity) {
            this.weakReference = new WeakReference<>(activity);
        }
        @Override
        public void handleMessage(Message msg) {
            Activity activity = weakReference.get();
            if (activity != null) {
                switch (msg.what) {
                    case DOWN_LOADING:
                        ((MainActivity) activity).tvResult.setText("正在下载...");
                        break;
                    case DOWN_FINISH:
                        ((MainActivity) activity).tvResult.setText("下载完成");
                        break;
                    case DOWN_FAILED:
                        ((MainActivity) activity).tvResult.setText("下载失败");
                        break;
                    default:
                        break;
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myHandler = new MyHandler(this);
        tvResult = findViewById(R.id.tv_result);
        btnDownload = findViewById(R.id.btn_download);
        btnDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //方法一 通过handler.sendMessage()/sendEmptyMessage()
                //new Method1().start();
                //方法二 通过handler.post(new Runnable())  post内部执行线程就是创建handler的线程
                new Method2().start();
                //方法三 通过handler.obtainMessage(what).sendToTarget()
                //new Method3().start();

                //在子线程中创建Handler
                //new Run().start();
            }
        });
    }

    class Method1 extends Thread {
        @Override
        public void run() {
            isDownloading = true;
            myHandler.sendEmptyMessage(DOWN_LOADING);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message msg = new Message();
            msg.what = DOWN_FINISH;
            msg.obj = "数据等。。。。";
            myHandler.sendMessage(msg);
            isDownloading = false;
        }
    }

    class Method2 extends Thread {
        @Override
        public void run() {
            Log.e("wdl", "Method2 Thread ID:" + Thread.currentThread().getId() +
                    " Thread Name:" + Thread.currentThread().getName());
            isDownloading = true;
            myHandler.sendEmptyMessage(DOWN_LOADING);
//            try {
//                Thread.sleep(3000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
            //三秒后执行
            myHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Log.e("wdl", "postDelayed Thread ID:" + Thread.currentThread().getId() +
                            " Thread Name:" + Thread.currentThread().getName());
                    tvResult.setText("下载成功");
                }
            },3000);

            //post 中所执行的线程就是创建myHandler所在的线程
//            myHandler.post(new Runnable() {
//                @Override
//                public void run() {
//                    Log.e("wdl", "Runnable Thread ID:" + Thread.currentThread().getId() +
//                            " Thread Name:" + Thread.currentThread().getName());
//                    tvResult.setText("下载成功");
//                }
//            });
            isDownloading = false;
        }
    }

    class Method3 extends Thread {
        @Override
        public void run() {
            isDownloading = true;
            //sendToTarget将生成的Message对象发送到对应的消息队列中
            myHandler.obtainMessage(DOWN_LOADING).sendToTarget();
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            myHandler.obtainMessage(DOWN_FINISH).sendToTarget();
            isDownloading = false;
        }
    }

    class Run extends Thread{
        private Handler handler;
        @SuppressLint("HandlerLeak")
        @Override
        public void run() {
            Log.e("wdl", "Run Thread ID:" + Thread.currentThread().getId() +
                    " Thread Name:" + Thread.currentThread().getName());
            //在子线程中创建handler时，必须指定Looper，否则会报错
            //java.lang.RuntimeException:
            //          Can't create handler inside thread that has not called Looper.prepare()
            //指定handler的Looper为主线程的Looper

            //为当前线程创建Looper
            //Looper.prepare();

            handler = new Handler(Looper.getMainLooper()){
                @Override
                public void handleMessage(Message msg) {
                    Log.e("wdl", "handleMessage Thread ID:" + Thread.currentThread().getId() +
                            " Thread Name:" + Thread.currentThread().getName());
                }
            };
            handler.sendEmptyMessage(1);
        }
    }
}
