import java.io.*;

public class IOLearning {
    static String filePath = "G:" + File.separator + "io_test" + File.separator + "io_test.txt";
    static String newFilePath = "G:" + File.separator + "io_test" + File.separator + "new_io_test.txt";

    public static void main(String[] args) {
        System.out.println(readFileWithFileInputStream(filePath));
        System.out.println(readFileWithBufferedInputStreamAndFileInputStream(filePath));
        writeFileWithBufferedOutputStreamAndFileOutputStream(filePath, newFilePath);
    }

    //使用FileInputStream读取指定路径文件的内容
    private static String readFileWithFileInputStream(String path) {
        FileInputStream fis = null;
        StringBuilder builder = new StringBuilder();
        try {
            fis = new FileInputStream(path);
            byte[] bytes = new byte[1024];
            int len;
            while ((len = fis.read(bytes)) != -1) {
                builder.append(new String(bytes, 0, len,"gbk"));
            }
            // System.out.println(builder.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(fis);
        }
        return builder.toString();
    }

    //FileInputStream  BufferedInputStream读取文件信息
    public static String readFileWithBufferedInputStreamAndFileInputStream(String path) {
        StringBuilder builder = new StringBuilder();
        FileInputStream fis = null;
        BufferedInputStream bis = null;
        try {
            fis = new FileInputStream(path);
            bis = new BufferedInputStream(fis);
            int len;
            byte[] bytes = new byte[1024];
            while ((len = bis.read(bytes)) != -1) {
                //设置格式，避免中文乱码
                builder.append(new String(bytes, 0, len, "gbk"));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(fis);
            close(bis);
        }
        return builder.toString();
    }

    //FileInputStream  BufferedInputStream读取文件信息后直接写入新的文件
    public static void writeFileWithBufferedOutputStreamAndFileOutputStream(String path, String newPath) {
        FileInputStream fis = null;
        FileOutputStream fos = null;
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            fis = new FileInputStream(path);
            fos = new FileOutputStream(newPath);
            bis = new BufferedInputStream(fis);
            bos = new BufferedOutputStream(fos);
            int len;
            byte[] bytes = new byte[1024];
            while ((len = bis.read(bytes)) != -1) {
                //设置格式，避免中文乱码
                //builder.append(new String(bytes, 0, len, "gbk"));
                bos.write(bytes, 0, len);
            }
            bos.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(fis);
            close(bis);
            close(fos);
            close(bos);
        }
    }

    public static void close(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


