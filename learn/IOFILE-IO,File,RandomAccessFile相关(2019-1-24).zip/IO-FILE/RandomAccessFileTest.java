import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.io.*;
import java.net.URLEncoder;

//RandomAccessFile 本身是字节流
//seek()方法将文件指针设置在文件中的特定位置。
//skipBytes（long n）跳过n个字节
//getFilePointer() 获得文件指针
//length() 获取文件长度
//RandomAccessFile的length（）方法返回文件的当前长度。我们可以通过使用其setLength()方法来扩展或截断文件。
//一系列的writeX()方法
//TODO 待解决  中文乱码


//四种模式
//"r" ：只读模式
//"rw" : 读写模式,文件不存在时，会自动创建
//"rws" ：读写模式，对文件的内容以及其元数据的任何修改立即被写入存储设备
//"rwd" : 读写模式，对文件内容的任何修改立即被写入存储设备

public class RandomAccessFileTest {
    static final String filePath = "G:" + File.separator + "io_test" + File.separator + "io_test.txt";
    static int count = 0;
    static String str = "random_access_file/测试";

    public static void main(String[] args) {
        //System.out.println(readOnlyFile());
        //wrMode();
//        try {
//            RandomAccessFile raf = new RandomAccessFile("G:" + File.separator + "random_access_file.txt", "rw");
//            raf.seek(15);
//            System.out.println(raf.length());
//            raf.writeUTF("插入的数据");
//            //写入一个int类型的数据
//            // raf.writeInt(count);
//            //raf.writeDouble(5.6);
//            // raf.write("你好？aa".getBytes());
//            //raf.writeUTF(str);
//            //int value = raf.readInt();
//            //System.out.println(value);
//
////            //解决乱码的方法之一
////            byte[] bytes = new byte[3];
////            ByteArrayOutputStream baos = new ByteArrayOutputStream();
////            int len;
////            while((len=raf.read(bytes))!=-1){
////                //截断后再次出现乱码
////                baos.write(bytes,0,len);
////
////            }
////            System.out.println(new String(baos.toByteArray()));
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        insert(8,"这是插入的数据");

    }

    //pos 代表要插入的光标位置
    //str 要插入的值
    public static void insert(long pos, String str) {
        FileOutputStream fos = null;
        FileInputStream fis = null;
        try {
            RandomAccessFile raf
                    = new RandomAccessFile("G:" + File.separator + "random_access_file.txt",
                    "rw");
            //创建临时空文件
            File tempFile = File.createTempFile("temp", null);
            //在虚拟机终止时，请求删除此抽象路径名表示的文件或目录
            tempFile.deleteOnExit();
            //将光标移至要插入数据的位置
            raf.seek(pos);
            byte[] bytes = new byte[1024];
            int len;
            fos = new FileOutputStream(tempFile);
            fis = new FileInputStream(tempFile);
            //将光标后的数据写入临时文件
            while ((len = raf.read(bytes)) != -1) {
                fos.write(bytes, 0, len);
            }
            fos.flush();

            //将光标移至要插入数据的位置,因为上面将插入位置之后的数据全部写入临时文件，光标为文件长度，需要重新定位
            raf.seek(pos);
            //插入内容
            raf.writeUTF(str);
            //再次追加原先的内容
            byte b[] = new byte[1024];
            int len1;
            while ((len1 = fis.read(b)) != -1) {
                raf.write(b, 0, len1);
            }

            raf.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            close(fos);
            close(fis);

        }
    }

    //只读模式下的读取
    public static String readOnlyFile() {
        //
        RandomAccessFile raFileReadOnly = null;
        StringBuilder builder = new StringBuilder();
        try {
            //创建一个 只读的随机访问
            raFileReadOnly = new RandomAccessFile(filePath,
                    "r");
            byte[] bytes = new byte[1024];
            int len;
            while ((len = raFileReadOnly.read(bytes)) != -1) {
                builder.append(new String(bytes, 0, len, "gbk"));
            }
            //只读模式下只能读取，写入报错 拒绝访问
            // raFileReadOnly.write('c');
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (raFileReadOnly != null)
                    raFileReadOnly.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return builder.toString();
    }

    //读写模式
    public static void wrMode() {
        RandomAccessFile raFileRw = null;
        //StringBuilder builder = new StringBuilder();
        try {
            raFileRw = new RandomAccessFile(filePath, "rw");
            long len = raFileRw.length();
            raFileRw.skipBytes((int) len);
            raFileRw.writeUTF("测试一");
            long point = raFileRw.getFilePointer();
            System.out.println("point:" + point + "len:" + len);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (raFileRw != null) {
                try {
                    raFileRw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    public static void close(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
