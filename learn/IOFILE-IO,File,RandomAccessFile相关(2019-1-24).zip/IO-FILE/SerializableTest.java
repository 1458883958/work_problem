import java.io.*;

public class SerializableTest implements Serializable {
    private static final long serialVersionUID = 1L;
    public static int count = 5;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

//    private void writeObject(ObjectOutputStream oos){
//        try {
//            ObjectOutputStream.PutField putField = oos.putFields();
//            System.out.println("原始密码："+password);
//            putField.put("password","password+md5");
//            System.out.println("加密后的密码：password+md5");
//            oos.writeFields();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    private void readObject(ObjectInputStream ois){
//        try {
//            ObjectInputStream.GetField getField = ois.readFields();
//            Object psd = getField.get("password","");
//            System.out.println("要解密的串："+psd.toString());
//            password = "解密过程--获取密钥";
//            System.out.println("解密后的密码："+password);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//    }

    //序列化时不保存静态变量
    //即序列化保存的是对象的状态，而静态变量是属于类的状态
    public static void main(String[] args) {
        try {
            //写入一次
            File file = new File("G:"+File.separator+"test.obj");
            ObjectOutputStream obs = new ObjectOutputStream(new FileOutputStream(file));
            SerializableTest t = new SerializableTest();
            obs.writeObject(t);
            obs.flush();
            System.out.println("第一次写入后的文件长度："+file.length());

            //写入第二次
            obs.writeObject(t);
            System.out.println("第二次写入后的文件长度："+file.length());
            obs.close();

            //读序列化文件
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
            SerializableTest test1 = (SerializableTest) ois.readObject();
            SerializableTest test2 = (SerializableTest) ois.readObject();
            //
            System.out.println("两次反序列化的引用是否相同"+(test1 == test2));
            ois.close();

            //输出静态变量，输出的是修改后的值
            //System.out.printf(String.valueOf(test.name));
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
