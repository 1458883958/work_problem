import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.SimpleFormatter;

public class FileLearning {
    public static void main(String[] args) {
        //通过将给定路径名字符串转换成抽象路径名来创建一个新 File 实例。
        String filename = "name/file1.txt";
        //通过文件名创建一个file对象
        File filex = new File("F:" + File.separator + "file2.txt");
        //根据 parent 路径名字符串和 child 路径名字符串创建一个新 File 实例。
        //File filey = new File("F:" + File.separator + "file", "text.txt");
        File filey = new File("F:" + File.separator + "file" + File.separator + "file1" + File.separator + "file2");
        if (!filey.exists()) {
            //创建全部的父目录文件夹
            filey.mkdirs();
//            try {
//                filey.createNewFile();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
        }
        System.out.println(filey.getAbsolutePath());
        System.out.println(filex.renameTo(new File("renameTo.txt")));
        System.out.println("renameTo:" + filex.getName());
        String[] fl = filey.list();
        for (String s : fl) {
            System.out.println(s);
        }

        if (!filex.exists()) {
            try {
                filex.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println(filex.getAbsolutePath());
        //通过给定的父抽象路径名和子路径名字符串创建一个新的File实例。
        File file = new File(new File("F:" + File.separator), filename);
        //不管文件是否真实存在，都可以输出文件的绝对路径
        // System.out.println(file.getAbsolutePath());
        //判断文件是否真实存在
        boolean isExists = file.exists();
        if (isExists) {
            System.out.println(file.getAbsolutePath());
            //删除文件
            //需要注意的是当删除某一目录时，必须保证该目录下没有其他文件才能正确删除，否则将删除失败。
            //file.delete();
        } else {
            //创建文件夹，假如父目录不存在，会报错
            //判断父目录是否存在
            //存在则直接创建文件
            if (file.getParentFile().exists()) {
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                //mkdir( )方法创建一个文件夹，成功则返回true，失败则返回false。失败表明File对象指定的路径已经存在，或者由于整个路径还不存在，该文件夹不能被创建。
                //file.getParentFile().mkdir();
                //mkdirs()方法创建一个文件夹和它的所有父文件夹。
                file.getParentFile().mkdirs();
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


        }
        //获取文件名或者目录名/获取父目录名
        System.out.println("getName:" + file.getName() + "    getParent:" + file.getParent());
        //输出绝对路径
        System.out.println("mkdir:" + file.getAbsolutePath());
        //将此抽象路径名转换为一个路径名字符串。
        System.out.println("mkdir:" + file.getPath());
        //测试此抽象路径名是否为绝对路径名。
        System.out.println(file.isAbsolute());
        //判断是否为目录
        System.out.println(file.isDirectory());
        String path = "G:\\as_work\\cardplus\\app\\src\\main";
        ArrayList<String> list = new ArrayList<>();

        getAllFileName(path, list);
        list.forEach(it -> {
            System.out.println(it);
        });

        //deleteFolder(new File("F:\\java"));

        try {
            //创建临时文件
            File file1 = File.createTempFile("temp", "txt");
            //只读
            file1.setReadOnly();
            //可读
            file1.setReadable(true);
            //可写
            file1.setWritable(true);
            //可执行
            file1.setExecutable(true);
            //获取最后一次修改的时间
            long date = file1.lastModified();
            Date x = new Date();
            x.setTime(date);
            System.out.println(new SimpleDateFormat().format(x));

            //设置最后一次修改的时间
            file1.setLastModified(new Date().getTime());
            //文件是否隐藏
            file1.isHidden();
            //获取文件长度
            long len = file1.length();


        } catch (IOException e) {
            e.printStackTrace();
        }


    }


    //获取所有文件
    public static void getAllFileName(String path, ArrayList<String> list) {
        File file = new File(path);
        //获取全部File
        //返回目录名加文件名
        //添加过滤器
//        String[] strings = file.list();
//        for (String string : strings) {
//            System.out.println(string);
//        }
        //这些路径名表示此抽象路径名所表示目录中的文件。
        File[] files = file.listFiles(new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                return true;
            }
        });
        for (int i = 0; i < files.length; i++) {
            //判断是否是目录，是的话继续递归
            if (files[i].isDirectory()) {
                getAllFileName(files[i].getAbsolutePath(), list);
            } else {
                //否则添加到list
                //获取全部文件名
                list.add(files[i].getName());
                //获取全部包+文件名
                //list.add(files[i].getAbsolutePath());
            }
        }
    }

    //需要注意的是当删除某一目录时，必须保证该目录下没有其他文件才能正确删除，否则将删除失败。
    public static void deleteFolder(File folder) throws Exception {
        if (!folder.exists()) {
            throw new Exception("文件不存在");
        }
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    //递归直到目录下没有文件
                    deleteFolder(file);
                } else {
                    //删除
                    file.delete();
                }
            }
        }
        //删除
        folder.delete();

    }
}
