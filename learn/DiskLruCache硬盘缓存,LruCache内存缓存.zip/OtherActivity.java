package com.example.photowalldemo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.photowalldemo.libcore.io.DiskLruCache;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class OtherActivity extends AppCompatActivity {
    private DiskLruCache mDiskLruCache;

    private Button btnGet;
    private ImageView ivBit;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);
        btnGet = findViewById(R.id.btn_get);
        ivBit = findViewById(R.id.iv_bit);
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://img-my.csdn.net/uploads/201309/01/1378037235_7476.jpg";
                //获取缓存文件名
                String key = Util.hashKeyForDisk(url);
                try {
                    DiskLruCache.Snapshot snapshot = mDiskLruCache.get(key);
                    if (snapshot!=null){
                        InputStream is = snapshot.getInputStream(0);
                        Bitmap bitmap  = BitmapFactory.decodeStream(is);
                        ivBit.setImageBitmap(bitmap);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        //完整的下载并写入缓存的操作为
        try {
            mDiskLruCache = DiskLruCache.open(Util.getDiskCacheDir(OtherActivity.this,
                    "bitmap"), Util.getVersionCode(OtherActivity.this), 1, 10 * 1024 * 1024);
        } catch (IOException e) {
            e.printStackTrace();
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = "https://img-my.csdn.net/uploads/201309/01/1378037235_7476.jpg";
                    //获取缓存文件名
                    String key = Util.hashKeyForDisk(url);

                    DiskLruCache.Editor editor = mDiskLruCache.edit(key);
                    if (editor != null) {
                        OutputStream os = editor.newOutputStream(0);
                        if (Util.downUrlToStream(url, os)) {
                            editor.commit();
                        } else {
                            editor.abort();
                        }
                    }
                    mDiskLruCache.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
