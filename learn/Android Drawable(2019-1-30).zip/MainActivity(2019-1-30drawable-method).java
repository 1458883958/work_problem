package com.example.administrator.drawabletest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    private ImageView ivImage;
    private Button btnGetWH;

    //将图片移动到分辨率低的drawable文件夹下，图片会随之比变大
    //android会使用匹配规则选择最适应的图片;
    // 假如:当前屏幕dpi为560*560就会优先选择xxxhdpi下的资源
    // 没有则往高密度查找，高密度也没有则倒序往低密度文件夹找 xhdpi->hdpi->mdpi->ldpi
    // 查找到低密度 放大，高密度 缩小

    //drawable-nodpi：在高密度找不到情况下，匹配规则的优先级大余drawable-hdpi   与密度无关的，图片不会进行放大缩小
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivImage = findViewById(R.id.iv_image);
        btnGetWH = findViewById(R.id.btn_getWH);
        btnGetWH.setOnClickListener(this);


        //如果将一张图片放在低密度文件夹下，那么在高密度设备上显示图片时就会被自动放大，
        // 而如果将一张图片放在高密度文件夹下，那么在低密度设备上显示图片时就会被自动缩小。
        //放大后容易造成OOM，所以建议放在高密度文件夹下



        //取每种dpi的最大值与设备对应dpi文件夹的dpi值，计算出比例，即可推算出放大后图片的宽高
        //xxxhdpi 236*420      640dpi
        //xxhdpi  315*560      480dpi   1.333倍 放大
        //xhdpi   473*840      320dpi   2倍 放大

        //nodpi的匹配优先级处于xh-h之间

        //hdpi    630*1120     240dpi   2.667倍 放大
        //mdpi    945*1680     160dpi   4倍 放大
        //ldpi    1260*2240    120dpi   5.33倍 放大

        //1440*2880屏幕像素   //图片270*480  为屏幕的1/6
        float xdpi = getResources().getDisplayMetrics().xdpi;
        float ydpi = getResources().getDisplayMetrics().ydpi;
        float density = getResources().getDisplayMetrics().density;
        //模拟器  560*560
        Log.e(TAG, "xdpi:" + xdpi + " ydpi:" + ydpi+" density:"+density);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_getWH:
                showToast("宽：" + ivImage.getWidth() + " 高：" + ivImage.getHeight());
                break;
            default:
                break;
        }
    }

    private void showToast(String str) {
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }
}
