import 'package:dart_learn/dart_learn.dart' as dart_learn;
import 'package:meta/meta.dart';

//--------------------函数-------------------------
/*
* 可选参数
    可选的命名参数
    可选的位置参数
  默认参数值
  main() 函数
  函数是一等公民（Functions as first-class objects）
  匿名函数
  词法作用域
  词法闭包
  判断函数相等
  返回值
* 
* */

//函数也为对象具有类型和功能（可分配给变量及作为参数传递）；省略返回值类型仍然可以工作

//main函数 主函数，程序入口
main(List<String> arguments) {
  print(isNull("str"));
  print(isNullSingle("str"));

  setInfo(name: 'wdl', age: 25, sex: false);
  setInfo(name: 'wdl', sex: false);

  print(say('wdl', 'hello'));
  print(say('wdl', 'hello', 'ss', true));

  print(defaultParam());
  print(defaultParam(name: 'lj'));

  print(defaultPositionParam());
  print(defaultPositionParam('lj'));

  stuff();
  stuff(list: [1, 1, 1], map: {'q': 5});

  //  /**
  //   * Applies the function [f] to each element of this collection in iteration
  //   * order.
  //   */
  //  void forEach(void f(E element)) {
  //    for (E element in this) f(element);
  //  }
  var list = [1, 1996, 4, 4, 3];
  list.forEach(printElement);

  var msg = 'giudsgk';
  var res = (msg) { return msg;};
  print(res);
}

//将函数作为参数
void printElement(int element) {
  print('$element');
}

//将list map 作为默认值
void stuff(
    {List<int> list = const [1, 2, 3],
    Map<String, int> map = const {'a': 1, 'b': 2}}) {
  print('list:$list');
  print('map:$map');
}

//使用=号来定义位置参数的默认值（为编译时常量，如未提供默认值为null），
String defaultPositionParam([String name = 'wdl']) => name;

//使用=号来定义命名参数以的默认值（为编译时常量，如未提供默认值为null），
String defaultParam({String name = 'wdl'}) => name;

//可选的位置参数  [type:value...]   []中包含一组位置参数
String say(String name, String content, [String device, bool sex]) {
  var result = '$name says $content';
  if (device != null) {
    result = '$result with a $device';
  }
  return result;
}

//可选的命名参数 functionName({...})表示
//Flutter小部件构造函数只使用可选命名参数
//可加上注解@required表示必传参数
//Required在元包中被定义。或者直接使用import package:meta/meta.dart导入
void setInfo({@required String name, int age, bool sex}) =>
    print('name:$name age:$age sex:${sex ? '女' : '男'}');

//bool 可省略
bool isNull(String str) {
  return str.isEmpty;
}

//只包含一个表达式的函数可使用简写，=>
//=>expr 语法是{return expr;}的简写写法。“=>”符号有时被称为胖箭头语法。 =>和；之间只能出现一个表达式
bool isNullSingle(String str) => str.isEmpty;
