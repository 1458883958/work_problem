package com.example.administrator.strategy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.strategy.strategymode.CashContext;


public class MainActivity extends AppCompatActivity {

    private Button btnCaculate;
    private EditText etPrice;
    private EditText etCount;
    private TextView tvResult;
    private RadioGroup rgGroup;
    private int resId = -1;
    private CashContext cashContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rgGroup = findViewById(R.id.rg);
        btnCaculate = findViewById(R.id.btn_cac);
        etPrice = findViewById(R.id.et_price);
        etCount = findViewById(R.id.et_count);
        tvResult = findViewById(R.id.tv_result);
        resId = R.id.rb_normal;
        rgGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                resId = checkedId;
            }
        });
        btnCaculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String price = etPrice.getText().toString();
                String count = etCount.getText().toString();
                if (!TextUtils.isEmpty(price) && !TextUtils.isEmpty(count)) {
                    if ((!price.contains(".") && price.substring(0, 1).equals("0")) ||
                            (!count.contains(".") && count.substring(0, 1).equals("0")))
                        Toast.makeText(MainActivity.this, "输入单价或者数量有问题", Toast.LENGTH_SHORT).show();
                    else {
                        cashContext = new CashContext(resId);
                        tvResult.setText("应收："+String.valueOf(cashContext.getResult(price, count)));
                    }
                }
            }
        });
    }
}
