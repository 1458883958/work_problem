package com.example.administrator.strategy.strategymode;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 创建时间： 2019/1/25 13:44
 * 描述：    满返回的具体算法实现
 *          具体的策略角色
 */
@SuppressWarnings("unused")
public class CashReturn extends CashSuper {
    private double moneyCondition;
    private double moneyReturn;

    /**
     * 构造
     *
     * @param moneyCondition 满多少金额
     * @param moneyReturn    返多少金额
     */
    public CashReturn(double moneyCondition, double moneyReturn) {
        this.moneyCondition = moneyCondition;
        this.moneyReturn = moneyReturn;
    }

    @Override
    public double acceptCash(String money) {
        BigDecimal value = new BigDecimal(money);
        BigDecimal bgCondition = new BigDecimal(String.valueOf(this.moneyCondition));
        //判断金额是否大于300
        if (value.compareTo(bgCondition) >= 0) {
            return value.subtract(value.divide(bgCondition, 2, RoundingMode.HALF_UP)
                    .multiply(new BigDecimal(String.valueOf(this.moneyReturn)))).doubleValue();
        } else {
            return value.doubleValue();
        }


    }
}
