package com.example.administrator.strategy.strategymode;

import java.math.BigDecimal;

/**
 * 创建时间： 2019/1/25 13:40
 * 描述：    打折算法的具体实现类
 *          具体的策略角色
 */
@SuppressWarnings("unused")
public class CashRebate extends CashSuper {
    private double rebate;

    /**
     * @param rebateRate 打折的程度
     */
    public CashRebate(double rebateRate) {
        this.rebate = rebateRate;
    }

    /**
     * @param money 收取现金
     * @return 返回打折后应收
     */
    @Override
    public double acceptCash(String money) {
        BigDecimal value = new BigDecimal(money);
        return value.multiply(new BigDecimal(String.valueOf(rebate))).doubleValue();

    }
}
