package com.example.administrator.strategy.strategymode;

import java.math.BigDecimal;

/**
 * 创建时间： 2019/1/25 13:38
 * 描述：    具体的某个优惠方式，即算法的具体实现
 *          具体的策略角色
 */
@SuppressWarnings("unused")
public class CashNormal extends CashSuper {
    /**
     * @param money 收取现金
     * @return 返回最终的金额
     */
    @Override
    public double acceptCash(String money) {
        BigDecimal value = new BigDecimal(money);
        return value.doubleValue();
    }
}
