package com.example.administrator.strategy.strategymode;

/**
 * 创建时间： 2019/1/25 13:36
 * 描述：    抽象的策略角色：可以是接口可以是抽象类
 *          策略模式中的策略类 Strategy
 *          定义所有支持算法的公共接口
 */
@SuppressWarnings("unused")
public abstract class CashSuper {
    /**
     * @param money 收取现金
     * @return 返回应收金额
     */
    public abstract double acceptCash(String money);
}
