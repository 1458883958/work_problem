package com.example.administrator.strategy.strategymode;

import com.example.administrator.strategy.R;

import java.math.BigDecimal;

/**
 * 创建时间： 2019/1/25 13:51
 * 描述： 环境角色：供客户端调用，内部持有策略类的引用
 *       Context层: 添加简单的工厂模式
 *       提供策略的实现
 */
@SuppressWarnings("unused")
public class CashContext {

    private CashSuper cashSuper;

    /**
     * 根据传入的resID创建对应的收费策略
     *
     * @param redId 选择ID
     */
    public CashContext(int redId) {
        switch (redId) {
            //正常
            case R.id.rb_normal:
                cashSuper = new CashNormal();
                break;
            //8折
            case R.id.rb_20_off:
                cashSuper = new CashRebate(0.8d);
                break;
            //6折
            case R.id.rb_40_off:
                cashSuper = new CashRebate(0.6d);
                break;
            //满300-100
            case R.id.rb_over_300_minus_100:
                cashSuper = new CashReturn(300d, 100d);
                break;
        }
    }

    /**
     * 暴露方法
     *
     * @param price 单价
     * @param count 数量
     * @return 实际收的钱
     */
    public double getResult(String price, String count) {
        BigDecimal p = new BigDecimal(price);
        BigDecimal c = new BigDecimal(count);
        return cashSuper.acceptCash(p.multiply(c).toString());
    }
}
