package com.cardplus.mobile.cardplus.ui;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.cardplus.mobile.cardplus.R;
import com.cardplus.mobile.cardplus.ap.MarginDesignActivity;
import com.cardplus.mobile.cardplus.net.pojo.Times;
import com.cardplus.mobile.cardplus.ui.bill.EditBillInfoActivity;
import com.cardplus.mobile.cardplus.utils.AppSharedUtil;
import com.cardplus.mobile.cardplus.utils.DateUtil;
import com.cardplus.mobile.cardplus.utils.LogUtil;
import com.cardplus.mobile.cardplus.widget.CusCalendarPickerView;
import com.cardplus.mobile.cardplus.widget.decorators.ControllDecorator;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.squareup.timessquare.CalendarCellDecorator;
import com.squareup.timessquare.CalendarCellView;
import com.squareup.timessquare.CalendarPickerView;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class SelectTaskTActivity extends MarginDesignActivity {
    private static final int MIN_SELECT = 3;
    private static final int MAX_SELECT = 20;
    private int count = 0;
    @BindView(R.id.ctl_title)
    CollapsingToolbarLayout toolbarLayout;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.btn_ok)
    Button ok;
    @BindView(R.id.tv)
    TextView tvAlready;
    @BindView(R.id.tv_toast)
    TextView toast;
    @BindView(R.id.tv_update)
    TextView updateDay;
    //    @BindView(R.id.calendarView)
//    MaterialCalendarView view;
    private List<String> mStampList = new ArrayList<>();
    private List<Times> mDays = new ArrayList<>();
    private static int year;
    private static int month;
    private static int day;
    private static int hour;

    static {
        //当前年月日
        year = DateUtil.getYear();
        month = DateUtil.getMonth();
        day = DateUtil.getDay();
        hour = DateUtil.getHour();
        todayStr = year + "-" + month + "-" + day;
    }

    //账单日
    private String bDate;
    //还款日
    private String dDate;
    private String billId;
    //今天
    private static String todayStr;
    private String initDayStr;
    private String bDatestr;
    private String dDatestr;
    @BindView(R.id.calendar_view)
    CusCalendarPickerView calendarPickerView;
    private List<CalendarCellDecorator> todayL = new ArrayList<>();
    private ControllDecorator bdateTrueDecora;
    private ControllDecorator bdateFalseDecora;
    private ControllDecorator ddateTrueDecora;
    private ControllDecorator ddateFalseDecora;

    //进入页面时默认选中的日期
    private List<Date> selectedDatas = new ArrayList<>();

    /**
     * 修改账单/还款日
     */
    @OnClick(R.id.tv_update)
    void update() {
        EditBillInfoActivity.show(this, 1, billId);
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bDate = getIntent().getStringExtra("bdate");
        dDate = getIntent().getStringExtra("ddate");
        billId = getIntent().getStringExtra("billId");
        initCalendar();
        LogUtil.e("hour:" + hour);

//        view.setOnDateChangedListener(this);
//        //final LocalDate instance = LocalDate.now();
//        CalendarDay calendarDay = CalendarDay.today();
        //view.setCurrentDate(instance);

        //今天标记 蓝点
//        view.addDecorator(new EventDecorator(getResources().getColor(R.color.colorBrand),
//                Collections.singletonList(calendarDay)));
//        final LocalDate instance = LocalDate.now();
//        int bd = Integer.valueOf(bDate);
//        int dd = Integer.valueOf(dDate);
//        if (bd < dd) {
//            b = LocalDate.of(instance.getYear(), instance.getMonth(), bd);
//            d = LocalDate.of(instance.getYear(), instance.getMonth(), dd);
//        } else {
//            b = LocalDate.of(instance.getYear(), instance.getMonth(), bd);
//            d = LocalDate.of(instance.getYear(), CalendarDay.today().getMonth() + 1, dd);
//        }
//        decorator11 = new HintDecorator("0", CalendarDay.from(this.b), false);
//        decorator22 = new HintDecorator("0", CalendarDay.from(this.b), true);
//        decorator33 = new HintDecorator("1", CalendarDay.from(this.d), false);
//        decorator44 = new HintDecorator("1", CalendarDay.from(this.d), true);
//        //LogUtil.e("date:" + b.toString() + " " + d.toString());
//
//        dec11 = new EventDecorator(getResources().getColor(R.color.green),
//                Collections.singletonList(CalendarDay.from(b)));
//        dec22 = new EventDecorator(getResources().getColor(R.color.red),
//                Collections.singletonList(CalendarDay.from(d)));
        //圆点
//        view.addDecorator();
//        view.addDecorator(new EventDecorator(getResources().getColor(R.color.red),
//                Collections.singletonList(CalendarDay.from(d))));

        //文字
        //       view.addDecorators(decorator22, decorator44);
        setBarTitle(R.string.select_task_t);
        String tv = String.format(getResources().getString(R.string.already_select_t), count);
        tvAlready.setText(tv);
    }

    private String getStr(Date date) {
        String dates = DateUtil.dateToString(date);
        //时间戳
        String value = "" + (date.getTime() / 1000);
        String[] s = dates.split("-");
        mStampList.add(value);
        mDays.add(new Times(Integer.valueOf(s[1]), Integer.valueOf(s[2])));
        return dates;
    }

    private String getString(Date date) {
        return "" + (date.getTime() / 1000);

    }

    private Times time(Date date) {
        String dates = DateUtil.dateToString(date);
        String[] s = dates.split("-");
        for (Times time : mDays) {
            if(time.getMonth()==Integer.valueOf(s[1])&&time.getDay()==Integer.valueOf(s[2])){
                return time;
            }
        }
        return null;
    }

    private void initCalendar() {
        int b = Integer.valueOf(bDate);
        final int d = Integer.valueOf(dDate);
        boolean flag = true;
        if (d <= day) {
            dDatestr = year + "-" + (month + 1) + "-" + d;
            flag = true;
        } else {
            dDatestr = year + "-" + month + "-" + d;
            flag = false;
        }
        bDatestr = year + "-" + month + "-" + b;

        int initDay;
        //账单日大于今日，起点为账单日
        if (b > day) {
            initDay = b;
        } else {
            if (hour >= 17) {
                initDay = day + 1;
            } else {
                initDay = day;
            }
        }
        Calendar next = Calendar.getInstance();
        next.setTime(DateUtil.stringToDate(dDatestr));
        //获取账单日
        int nextSum = next.get(Calendar.DATE);
        LogUtil.e("bDatestr:" + bDatestr + " dDatestr:" + dDatestr);

        final Calendar nextmonth = Calendar.getInstance();
        //月份
        //获取这个月的天数
        int sum = nextmonth.getActualMaximum(Calendar.DAY_OF_MONTH);
        sum = sum - initDay;
        LogUtil.e("sum:" + sum + " nextSum:" + nextSum);
        final int countDay;
        if (!flag) {
            countDay = nextSum - initDay;
        } else {
            countDay = nextSum + sum;
        }
        nextmonth.add(Calendar.DATE, countDay + 2);
        initDayStr = year + "-" + month + "-" + initDay;

        String str = (String) AppSharedUtil.get(this, "dateString", "");
        if (TextUtils.isEmpty(str)) {
            calendarPickerView.init(DateUtil.stringToDate(initDayStr), nextmonth.getTime())
                    .inMode(CalendarPickerView.SelectionMode.MULTIPLE);
            toast.setText("不超过20天");
        } else {
            Gson gson = new Gson();
            Type type = new TypeToken<List<Date>>() {
            }.getType();
            selectedDatas = gson.fromJson(str, type);
            count = selectedDatas.size();
            for (Date selectedData : selectedDatas) {
                getStr(selectedData);
            }
            calendarPickerView.init(DateUtil.stringToDate(initDayStr), nextmonth.getTime())
                    .inMode(CalendarPickerView.SelectionMode.MULTIPLE).withSelectedDates(
                    selectedDatas
            );
            toast.setText(DateUtil.getBatchDateS(mDays));
        }


        bdateTrueDecora = new ControllDecorator(bDatestr, true, this, 1);
        bdateFalseDecora = new ControllDecorator(bDatestr, false, this, 1);
        ddateTrueDecora = new ControllDecorator(dDatestr, true, this, 2);
        ddateFalseDecora = new ControllDecorator(dDatestr, false, this, 2);
        calendarPickerView.setOnDateSelectedListener(new CalendarPickerView.OnDateSelectedListener() {
            @Override
            public void onDateSelected(Date date) {
                count++;
                selectedDatas.add(date);
                String dates = getStr(date);
                if (bDatestr.equals(dates)) {
                    todayL.add(bdateFalseDecora);
                    todayL.remove(bdateTrueDecora);
                    calendarPickerView.setDecorators(todayL);
                }
                if (dDatestr.equals(dates)) {
                    todayL.add(ddateFalseDecora);
                    todayL.remove(ddateTrueDecora);
                    calendarPickerView.setDecorators(todayL);

                }
                init();
                String tv = String.format(getResources().getString(R.string.already_select_t), count);
                tvAlready.setText(tv);
                if (count == 0)
                    toast.setText(getText(R.string.max_select_t));
                else
                    toast.setText(DateUtil.getBatchDateS(mDays));
            }

            @Override
            public void onDateUnselected(Date date) {
                count--;
                if (count<0)return;
                selectedDatas.remove(date);
                mStampList.remove(getString(date));
                //int index = mDays.indexOf(time(date));
                //LogUtil.e("index:"+index);
                mDays.remove(time(date));
                LogUtil.e("onDateUnselected:" + DateUtil.dateToString(date));
                if (bDatestr.equals(DateUtil.dateToString(date))) {
                    todayL.add(bdateTrueDecora);
                    todayL.remove(bdateFalseDecora);
                    calendarPickerView.setDecorators(todayL);
                }
                if (dDatestr.equals(DateUtil.dateToString(date))) {
                    todayL.add(ddateTrueDecora);
                    todayL.remove(ddateFalseDecora);
                    calendarPickerView.setDecorators(todayL);
                }
                init();
                String tv = String.format(getResources().getString(R.string.already_select_t), count);
                tvAlready.setText(tv);
                if (count == 0)
                    toast.setText(getText(R.string.max_select_t));
                else
                    toast.setText(DateUtil.getBatchDateS(mDays));

            }
        });
        calendarPickerView.setOnInvalidDateSelectedListener(new CalendarPickerView.OnInvalidDateSelectedListener() {
            @Override
            public void onInvalidDateSelected(Date date) {//去除不在范围内点击的toast
                Toast.makeText(SelectTaskTActivity.this, "当前日期不可选", Toast.LENGTH_SHORT).show();
                return;
            }
        });
        todayL.add(new TodayDecorator());
        todayL.add(bdateTrueDecora);
        todayL.add(ddateTrueDecora);
        calendarPickerView.setDecorators(todayL);

    }

    private void init() {
        if (count < MIN_SELECT) {
            ok.setEnabled(false);
            ok.setClickable(false);
            ok.animate().alpha(0.4f);
        } else if (count <= MAX_SELECT) {
            ok.setEnabled(true);
            ok.setClickable(true);
            ok.animate().alpha(1f);
        } else {
            //不得大于20天
            Toast.makeText(this, "任务周期不能大于20天，请重新选择", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Gson gson = new Gson();
        String dateString = gson.toJson(selectedDatas);
        LogUtil.e("onPause:" + dateString);
        AppSharedUtil.put(this, "dateString", dateString);
    }

    @Override
    public int getContainerLayout() {
        return R.layout.activity_select_task_t;
    }


//    @Override
//    public void onDateSelected(@NonNull MaterialCalendarView materialCalendarView, @NonNull CalendarDay calendarDay, boolean b) {
//        //周二,22 1月 2019
//        if (b) {
//            if (calendarDay.toString().equals(CalendarDay.from(this.b).toString())) {
//                view.removeDecorator(decorator22);
//                view.addDecorators(dec11, decorator11);
//            }
//            if (calendarDay.toString().equals(CalendarDay.from(this.d).toString())) {
//                view.removeDecorator(decorator44);
//                view.addDecorators(dec22, decorator33);
//            }
//            count++;
//            String dates = calendarDay.toString();
//            dates = dates.substring(dates.indexOf("{") + 1, dates.indexOf("}"));
//            String[] s = dates.split("-");
//            String value = dates;
//            try {
//                value = DateUtil.dateToStamp(value);
//            } catch (ParseException e) {
//                e.printStackTrace();
//            }
//            value = value.substring(0, 10);
//            mStampList.add(value);
//            mDays.add(new Times(Integer.valueOf(s[1]), Integer.valueOf(s[2])));
//        } else {
//            if (calendarDay.toString().equals(CalendarDay.from(this.b).toString())) {
//                view.removeDecorator(dec11);
//                view.addDecorators(decorator22);
//            }
//            if (calendarDay.toString().equals(CalendarDay.from(this.d).toString())) {
//                view.removeDecorator(dec22);
//                view.addDecorators(decorator44);
//            }
//            count--;
//            mStampList.remove(count);
//            mDays.remove(count);
//        }
//
//        String tv = String.format(getResources().getString(R.string.already_select_t), count);
//        tvAlready.setText(tv);
//        if (count == 0)
//            toast.setText(getText(R.string.max_select_t));
//        else
//            toast.setText(DateUtil.getBatchDateS(mDays));
//    }


    @OnClick(R.id.btn_ok)
    void confirm() {
        //mList = view.getSelectedDates();
        if (mDays == null || mDays.size() == 0) return;
        Intent intent = new Intent();
        intent.putStringArrayListExtra("arrays", (ArrayList<String>) mStampList);
        intent.putExtra("dates", DateUtil.getBatchDateS(mDays));
        LogUtil.e("dates:" + DateUtil.getBatchDateS(mDays));
        setResult(RESULT_OK, intent);
        count = 0;
        //view.clearSelection();
        this.finish();
    }


    class TodayDecorator implements CalendarCellDecorator {

        @Override
        public void decorate(CalendarCellView cellView, Date date) {
            cellView.getDayOfMonthTextView().setTextSize(11);
            cellView.getDayOfMonthTextView().setTypeface(Typeface.DEFAULT);
            if (!cellView.isCurrentMonth())
                return;
            if (java.sql.Date.valueOf(todayStr).compareTo(java.sql.Date.valueOf(DateUtil.dateToString(date))) == 0) {
                cellView.getDayOfMonthTextView().setBackground(ContextCompat.getDrawable(getApplicationContext(), R.drawable.schedule_time_tody_selector));
                cellView.getDayOfMonthTextView().setText("今天");
            }
        }
    }
}
