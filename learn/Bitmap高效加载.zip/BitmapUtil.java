package com.example.administrator.drawabletest;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

/**
 * 创建时间： 2019/2/15 16:00
 * 描述：    TODO
 */
@SuppressWarnings("unused")
public class BitmapUtil {
    /**
     * 计算缩放比率
     *
     * @param options BitmapFactory.Options
     * @param reqW    压缩后的宽
     * @param reqH    压缩后的高
     * @return 缩放比例
     */
    public static int calculateInSampleSize(BitmapFactory.Options options, int reqW, int reqH) {
        if (options == null) return 1;
        //源图片的宽高
        final int sourceW = options.outWidth;
        final int sourceH = options.outHeight;
        //缩放比例
        int sampleSize = 1;
        //原图宽高大于需要的宽高
        if (sourceW > reqW || sourceH > reqH) {
            //计算缩放比率
            final int wRatio = Math.round((float) sourceW / (float) reqW);
            final int hRatio = Math.round((float) sourceH / (float) reqH);
            //选择小的缩放比率，保证最终图片宽高大于等于目标宽高
            sampleSize = wRatio > hRatio ? hRatio : wRatio;
        }
        return sampleSize;
    }


    /**
     * 获取缩放后的图片
     *
     * @param options   BitmapFactory.Options
     * @param resources Resources
     * @param resId     资源ID
     * @param reqW      目标宽
     * @param reqH      目标高
     * @return 所需Bitmap
     */
    public static Bitmap decodeBitmapFromResource(BitmapFactory.Options options, Resources resources, int resId, int reqW, int reqH) {
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        options.inJustDecodeBounds = true;  //禁止为Bitmap分配内存
        //获取图片大小等信息,不生成像素数据
        BitmapFactory.decodeResource(resources, resId, options);
        //计算缩放比率
        options.inSampleSize = calculateInSampleSize(options, reqW, reqH);
        //再次解析图片
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(resources, resId, options);
    }
}
