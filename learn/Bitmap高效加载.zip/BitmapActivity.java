package com.example.administrator.drawabletest;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class BitmapActivity extends AppCompatActivity {
    private ImageView ivImage;
    private static final String TAG = "wdl";
    private TextView tvOption;
    int on = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bitmap);
        ivImage = findViewById(R.id.iv_image);
        tvOption = findViewById(R.id.tv_option);
//        优化方法一   改变config
//        options.inPreferredConfig = Bitmap.Config.RGB_565;
//
//        //优化方式二  选择合适的资源文件目录
//
//        优化方式三  缩放图片
        BitmapFactory.Options options = new BitmapFactory.Options();

//        options.inJustDecodeBounds = true;  //禁止为Bitmap分配内存
//        BitmapFactory.decodeResource(getResources(), R.drawable.bit, options);
//        options.inJustDecodeBounds = false;
        //高效加载大图避免OOM
        Bitmap bit = BitmapUtil.decodeBitmapFromResource(options, getResources(), R.drawable.bit, 100, 100);

        ivImage.setImageBitmap(bit);
        int w = bit.getWidth();
        int width = options.outWidth;
        int h = bit.getHeight();
        int height = options.outHeight;

        int densityDpi = getResources().getDisplayMetrics().densityDpi;
        int inDensity = options.inDensity;
        if (options.inPreferredConfig == Bitmap.Config.RGB_565)
            on = 2;
        else if (options.inPreferredConfig == Bitmap.Config.ARGB_8888)
            on = 4;
        //像素*4  ARGB_8888
        int memorySizeMethod1 = w * h * on;
        int memorySizeMethod2 = (int) (width * height * Math.pow(densityDpi / inDensity, 2) * on);

        StringBuilder builder = new StringBuilder();
        builder.append("w:").append(w).append("\n")
                .append("h:").append(h).append("\n")
                .append("memorySizeMethod1:").append(memorySizeMethod1).append("\n")
                .append("memorySizeMethod2:").append(memorySizeMethod2).append("\n")
                .append("config:").append(options.inPreferredConfig).append("\n")
                .append("资源目录分辨率-inDensity:").append(inDensity).append("\n")
                .append("inScreenDensity:").append(options.inScreenDensity).append("\n")
                .append("inTargetDensity:").append(options.inTargetDensity).append("\n")
                .append("设备分辨率-densityDpi:").append(densityDpi).append("\n")
                .append("dpiX:").append(getResources().getDisplayMetrics().xdpi).append("\n")
                .append("dpiY:").append(getResources().getDisplayMetrics().ydpi).append("\n");
        tvOption.setText(builder.toString());
        //Log.e(TAG, "w: " + w + " h: " + h + " " +  + " memorySize:" + w * h * 4);

    }
}
