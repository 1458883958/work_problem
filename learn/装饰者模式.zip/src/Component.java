
//对象接口，动态的给对象添加功能
public interface Component {
    void operation();
}
