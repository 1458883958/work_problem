
//装饰抽象类，实现装饰接口，从外类扩展Component的功能
public abstract class Decorator implements Component {
    private Component component;

    public void setComponent(Component component) {
        this.component = component;
    }

    @Override
    public void operation() {
        //先执行Component的operation
        if (this.component != null) {
            this.component.operation();
        }
    }
}
