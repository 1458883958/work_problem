
//具体的装饰对象，起到给Component添加功能
public class ConcreteDecoratorA extends Decorator {
    @Override
    public void operation() {
        //先执行Component.operation
        super.operation();
        System.out.println("具体装饰对象A的操作");
    }
}
