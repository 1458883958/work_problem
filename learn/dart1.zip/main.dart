import 'package:dart_learn/dart_learn.dart' as dart_learn;

main(List<String> arguments) {
  String a = "wdl";
  final b = 10;
  final String c = "10";

  //const 编译时常量
  //实例对象可以是final 不能是const
  const d = 20;

  //未初始化的值为null,因为在dart中所有的均为对象
  //$直接引用值无需拼接
  int aa;
  print('a:$a,b:$b,c:$c,d:$d,aa:$aa');

  //var 自动推断类型
  var name = "wdl";
  var age = 25;
  //dynamic 动态类型
  dynamic school = "三明学院";

  print('name:$name,age:$age,更改前school:$school');
  school = 123;
  print('更改后:$school');

  //内建类型

  //--------------------------------Numbers-------------------------------
  //int double 都是64位，均为Numbers子类
  int integer = 20;
  int hex = 0xDEABDBEEF;

  //包含一个小数就是双精度数
  double price = 20.1;
  double y = 1.42e5;
  print('integer:$integer hex:$hex price:$price y:$y');

  //字符串转数字的方法（数字转字符串反之）
  //字符串->数字  目标类型.parse('串')
  var one = int.parse('1');
  var onePointOne = double.parse('1.1');

  //数字转字符串  数字.
  var strOne = 1.toString();
  var strOnePointOne = 1.1.toString();
  //保留2位小数
  var strPi = 3.141592653.toStringAsFixed(2);

  print(
      'one:$one onePointOne:$onePointOne strOne:$strOne strOnePointOne:$strOnePointOne');

  //与或非/左移/右移    操作符
  var value = 3; //0011
  var right = value >> 1; //0011 - - 0001
  var left = value << 1; //0011 - - 0110
  var or = value | 4; //0011 | 0100 -- 01111 有一即一
  var and = value & 4; //0011 & 0100 -- 0000  全1为1
  print('right:$right left:$left or:$or and:$and');

  //数字字面量是编译时常量,均为常量可进行计算
  const c1 = 20;
  const c2 = 10.2;
  const result = c1 * c2;
  print('result:$result');

  //-------------------String-----------------
  //Dart中字符串是UTF-16编码单元的序列，可使用‘’ ""创建
  //使用${expression(代表表达式)}可获取对应的值
  final s = "wdl";
  var s1 = 'Hello Dart1,My Name is $s';
  var s2 = "Hello Dart2,My Name is ${s.toUpperCase()}";
  var isEqual = s1 == s2;
  print('s1:$s1\ns2:$s2\nisEqual:$isEqual');

  //可以使用相同的字符串字面量或者+进行字符拼接
  var s3 = 'My name' 'is $s,' "hahahhaha";
  var s4 = 'My name' + 'is $s,' + "hahahhaha";
  print('s3:$s3\ns4:$s4');

  //创建带有格式的字符串：使用''' '''或者"""  """
  var s5 = '''Hello!
  Dart.''';
  var s6 = """Hello!
  Dart.""";
  print('s5:$s5\ns6:$s6');

  //使用r前缀创建原始字符串，即\n等全部失效
  var s7 = r'In a raw string, not even \n gets special treatment.';
  print('s7:$s7');

  // These work in a const string.
  const aConstNum = 0;
  const aConstBool = true;
  const aConstString = 'a constant string';

  // 非const修饰在 const修饰的字面量中不可使用内插
  var aNum = 0;
  var aBool = true;
  var aString = 'a string';
  const aConstList = [1, 2, 3];

  //任何const修饰的字面量，其内插表达式 只能为 boolean num null string类型（也必须为const修饰）
  const validConstString = '$aConstNum $aConstBool $aConstString ';
  //包含list不可用
  //const validConstString = '$aConstNum $aConstBool $aConstString $aConstList';
  print('validConstString:$validConstString');

  //--------------------Booleans------------ 同java
  var fullName = "";
  print('fullName is Empty? ${fullName.isEmpty}');

  //--------------------Lists--------------
  //Dart中数组是对象列表(数组中的每个元素都是对象)
  var list = [1, 2, 3, 4, 'a'];
  print(list);
  var constList = const [1, 2, 3, 4, 4];
  print(constList[0]);

  //----------------------Maps-------------------
  var maps = {1: 1, 2: "aa", 8: 'aaaa'};
  var map = Map();
  //添加一个键值对
  map[1] = 'a';
  map[3] = 'aa';
  map[2] = 1;
  //检索一个值的方式，假如不存在与map中则返回null
  var boo = map[1] == 'a';

  //创建一个编译时常量map
  final mapx = const {'a': 1, 'v': 2};

  print('maps:$maps map:$map boo:$boo');

  //--------------Runes(字符)----------------
  //Dart中，字符是字符串的UTF-32编码点
  //codeUnitAt和codeUnit属性返回16位代码单元
  var clapping = '\u{1f600}';
  print(clapping);
  print(clapping.codeUnits);
  print(clapping.runes.toList());
  Runes input = new Runes(
      '\u2665  \u{1f605}  \u{1f60e}  \u{1f47b}  \u{1f596}  \u{1f44d}');
  print(new String.fromCharCodes(input));
  //反转
  var inputS = "Music \u{1d11e} for the win";
  print(new String.fromCharCodes(inputS.runes.toList().reversed));
  //print(inputS.split('').reversed.join(''));

  //------------------Symbols符号--------------

}
