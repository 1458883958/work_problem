package com.example.cachedemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.jakewharton.disklrucache.DiskLruCache;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * 创建时间： 2019/2/20 9:16
 * 描述：    TODO
 */
public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<String> mList;
    private LruCache<String, Bitmap> lruCache;
    private DiskLruCache mDiskLruCache;
    private Set<Task> tasks;
    private RecyclerView rv;
    private Context context;
    private boolean isScrolling = false;

    /**
     * 记录每个子项的高度。
     */
    private List<Integer> hList;//定义一个List来存放图片的height

    public Adapter(List<String> mList, Context context, RecyclerView rv) {
        this.mList = mList;
        this.rv = rv;
        this.context = context;
        tasks = new HashSet<>();

        hList = new ArrayList<>();
        for (int i = 0; i < mList.size(); i++) {
            //每次随机一个高度并添加到hList中
            int height = new Random().nextInt(200) + 300;//[100,500)的随机数
            hList.add(height);
        }
        //初始化内存缓存
        int size = (int) ((Runtime.getRuntime().maxMemory() / 1024) / 8);
        lruCache = new LruCache<String, Bitmap>(size) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };

        //初始化硬盘缓存
        try {
            File cacheDir = Util.getDiskCacheDir(context, "bitmap");
            if (!cacheDir.exists())
                cacheDir.mkdirs();
            mDiskLruCache = DiskLruCache.open(cacheDir,
                    Util.getVersionCode(context), 1, 30 * 1024 * 1024);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 创建viewHolder,将xml传给viewholder
     *
     * @param parent
     * @param viewType
     * @return
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
        final String urlStr = mList.get(position);
        //设置tag
        viewHolder.imageView.setTag(urlStr);
        //设置占位 防止图片错位
        viewHolder.imageView.setImageResource(R.drawable.ic_launcher_background);
        //设置宽高
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(context
                .getResources().getDisplayMetrics().widthPixels / 3, hList.get(position));
        viewHolder.imageView.setLayoutParams(params);

            loadBitmaps(viewHolder.imageView, urlStr);
    }

    public void setScrolling(boolean scrolling) {
        isScrolling = scrolling;
        notifyDataSetChanged();
    }

    /**
     * 加载图片
     *
     * @param imageView ImageView
     * @param urlStr    先从内存缓存中找，找不到，从硬盘缓存中找，找不到，网络下载并加载（存储硬盘缓存），存储到内存缓存
     */
    private void loadBitmaps(ImageView imageView, String urlStr) {
        Bitmap bitmap = getBitmapFromMemoryCache(urlStr);
        //根据滑动的状态判断是否加载图片
        if (bitmap == null&&!isScrolling) {
            Task task = new Task();
            tasks.add(task);
            task.execute(urlStr);
        } else {
            if (imageView != null) {
                imageView.setImageBitmap(bitmap);
            }
        }
    }


    @Override
    public int getItemCount() {
        return mList.size();
    }


    /**
     * 添加内存缓存中不存在的Bitmap
     *
     * @param key    键
     * @param bitmap 值
     */
    private void addBitmapToLruCache(String key, Bitmap bitmap) {
        if (getBitmapFromMemoryCache(key) == null)
            lruCache.put(key, bitmap);
    }

    /**
     * 从内存缓存中获取键为key的Bitmap
     *
     * @param key 键
     * @return Bitmap
     */
    private Bitmap getBitmapFromMemoryCache(String key) {
        return lruCache.get(key);
    }

    /**
     * 取消所有正在下载或等待下载的任务。
     */
    public void cancelAllTasks() {
        if (tasks != null) {
            for (Task task : tasks) {
                task.cancel(false);
            }
        }
    }


    /**
     * 将缓存记录同步到journal文件中。
     */
    public void flushCache() {
        if (mDiskLruCache != null) {
            try {
                mDiskLruCache.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.iv_image);
        }
    }


    class Task extends AsyncTask<String, Void, Bitmap> {

        private String imageUrl;

        @Override
        protected Bitmap doInBackground(String... strings) {
            imageUrl = strings[0];
            FileDescriptor fd = null;
            FileInputStream fis = null;
            DiskLruCache.Snapshot snapshot = null;
            try {
                //生成key
                final String key = Util.hashKeyForDisk(imageUrl);
                snapshot = mDiskLruCache.get(key);
                //如果未找到缓存，则从网络上下载并存储至缓存中
                if (snapshot == null) {
                    DiskLruCache.Editor editor = mDiskLruCache.edit(key);
                    if (editor != null) {
                        OutputStream os = editor.newOutputStream(0);
                        if (Util.downUrlToStream(imageUrl, os)) {
                            editor.commit();
                        } else {
                            editor.abort();
                        }
                    }
                    //缓存被写入后再次从缓存中查找
                    snapshot = mDiskLruCache.get(key);
                }
                if (snapshot != null) {
                    fis = (FileInputStream) snapshot.getInputStream(0);
                    fd = fis.getFD();
                }
                //将缓存数据加载成Bitmap
                Bitmap bitmap = null;
                if (fd != null) {
                    bitmap = BitmapFactory.decodeFileDescriptor(fd);
                }
                if (bitmap != null) {
                    //将bitmap写入内存缓存中去
                    addBitmapToLruCache(imageUrl, bitmap);
                }
                return bitmap;
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (fd == null && fis != null)
                        fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            ImageView imageView = rv.findViewWithTag(imageUrl);
            if (bitmap != null && imageView != null) {
                imageView.setImageBitmap(bitmap);
            }
            tasks.remove(this);

        }
    }
}
