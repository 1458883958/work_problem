package com.example.cachedemo;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.ViewTreeObserver;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;

import static android.support.v7.widget.RecyclerView.SCROLL_STATE_DRAGGING;
import static android.support.v7.widget.RecyclerView.SCROLL_STATE_IDLE;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv;
    private Adapter adapter;
    @Override
    protected void onPause() {
        super.onPause();
        adapter.flushCache();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 退出程序时结束所有的下载任务
        adapter.cancelAllTasks();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rv = findViewById(R.id.recycler_view);
        //设置瀑布流，2列竖直
        StaggeredGridLayoutManager layoutManager = new StaggeredGridLayoutManager(3,
                StaggeredGridLayoutManager.VERTICAL);
        //解决item跳动
       // layoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_NONE);
        rv.setLayoutManager(layoutManager);

        rv.setItemAnimator(null);
        adapter = new Adapter(Arrays.asList(Common.urls),this,rv);
        rv.setAdapter(adapter);

        //添加recycler view 滚动状态的监听，控制是否加载图片
        rv.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                switch (newState){
                    case SCROLL_STATE_IDLE:
                        //滑动停止
                        adapter.setScrolling(false);
                        break;
                    case SCROLL_STATE_DRAGGING:
                        //正在滚动
                        adapter.setScrolling(true);
                        break;

                }

            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });
//        Gson gson = new Gson();
//        List<Entity> mList = gson.fromJson(Common.s, new TypeToken<List<Entity>>() {
//        }.getType());
//        StringBuilder str = new StringBuilder();
//        for (Entity entity : mList) {
//            str.append("\"").append(entity.getUrl()).append("\",").append("\n");
//        }
//        Log.e("wdl",str.toString());

//        Entity[] entities = gson.fromJson(Common.s,new TypeToken<Entity>() {
//        }.getType());
//        for (Entity entity : entities) {
//            str.append(entity.getUrl()).append("\n");
//        }
//        Log.e("wdl",str.toString());
    }
}
