

//消费者
public class Consumer extends Thread{
    private Producer producer;
    private String name;

    public Consumer(Producer producer, String name) {
        super(name);
        this.producer = producer;
    }

    @Override
    public void run() {
        while(true){
            Message msg = producer.waitMessage();
            System.out.println(getName()+":"+msg.getContent());
        }
    }
}
