public class Notify_Wait_NotifyAll {
    public synchronized void test() {
        System.out.println("start:-------------");
        try {
            wait();//释放锁，进入等待状态，等待唤醒
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("end:-------------");
    }

    public static void main(String[] args) {
        Notify_Wait_NotifyAll test = new Notify_Wait_NotifyAll();
        for (int i = 0; i < 5; i++) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    test.test();
                }
            }).start();
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("唤醒一个线程：-----------------");
        synchronized (test) {
            test.notify();//唤醒   在有锁的基础上
        }
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("唤醒全部：---------------------");
        synchronized (test) {
            test.notifyAll();
        }
    }
}
