import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName());
        ExecutorService service = Executors.newFixedThreadPool(5);
        Producer producer = new Producer();
        service.execute(producer);
        //producer.run();
        service.execute(new Consumer(producer,"c1"));
        service.execute(new Consumer(producer,"c2"));
        service.execute(new Consumer(producer,"c3"));
        service.execute(new Consumer(producer,"c4"));
    }
}
