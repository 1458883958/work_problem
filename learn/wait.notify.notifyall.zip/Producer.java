import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//生产者,每隔三秒钟创建一条消息
public class Producer extends Thread {
    private List<Message> messages = new ArrayList<>();

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName());
        Random random = new Random(100);
        while (true) {
            try {
                Thread.sleep(3000);
                Message msg = new Message("message:" + random.nextInt(100));
                synchronized (messages) {
                    //System.out.println("-----产生一条消息-----");
                    messages.add(msg);
                    messages.notify();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public Message waitMessage() {
        synchronized (messages) {
            while (messages.size() == 0) {
                try {
                    //System.out.println("-----等待一条消息-----");
                    messages.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return messages.remove(0);
        }
    }
}
