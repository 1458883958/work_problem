import 'package:flutter/material.dart';

void main() => runApp(MyApp(
      list: new List<String>.generate(1000, (i) => 'Item $i'),
    ));

class MyApp extends StatelessWidget {
  final List<String> list;

  MyApp({Key key, @required this.list}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      title: 'List Widget',
      home: DnyList(list),
    );
  }
}

class DnyList extends StatelessWidget {
  final List<String> lists;

  DnyList(this.lists);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        body: new ListView.builder(
      itemCount: lists.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text('${lists[index]}'),
        );
      },
    ));
  }
}

class MyList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new ListView(
      scrollDirection: Axis.horizontal,
      //设置布局方向
      children: <Widget>[
        new Container(
          width: 200,
          color: Colors.lightBlue,
        ),
        new Container(
          width: 200,
          color: Colors.limeAccent,
        ),
        new Container(
          width: 200,
          color: Colors.purple,
        )
      ],
    );
  }
}
