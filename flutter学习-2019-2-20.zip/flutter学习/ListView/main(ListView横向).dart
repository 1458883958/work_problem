import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      title: 'Hello Flutter',
      home: Scaffold(
        body: Center(
          child: Container(
            height: 500,
            child: ListView(
              scrollDirection: Axis.horizontal,
              //设置布局方向
              children: <Widget>[
                new Container(
                  width: 200,
                  color: Colors.lightBlue,
                ),
                new Container(
                  width: 200,
                  color: Colors.limeAccent,
                ),
                new Container(
                  width: 200,
                  color: Colors.purple,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
 
}
