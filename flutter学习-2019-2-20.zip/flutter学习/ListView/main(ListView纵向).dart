import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      title: 'Hello Flutter ListView',
      home: Scaffold(
        appBar: AppBar(
          title: new Text('ListView'),
        ),
        body: new ListView(
          children: <Widget>[
            new ListTile(
              leading: new Icon(Icons.access_time),
              title: new Text('access_time'),
            ),
            new ListTile(
              leading: new Icon(Icons.account_balance),
              title: new Text('account_balance'),
            ),
            new Image.network(
              'https://ws1.sinaimg.cn/small/0065oQSqgy1fwyf0wr8hhj30ie0nhq6p.jpg',
              width: 300,
              height: 300,
            ),
            new Image.network(
              'http://ww1.sinaimg.cn/small/0065oQSqly1fsvb1xduvaj30u013175p.jpg',
              width: 300,
              height: 300,
            ),
            new Image.network(
              'http://ww1.sinaimg.cn/small/0065oQSqly1fsoe3k2gkkj30g50niwla.jpg',
              width: 300,
              height: 300,
            ),
          ],
        ),
      ),
    );
  }
}
