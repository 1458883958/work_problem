import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      title: 'List Widget',
      home: Scaffold(
        body: GridView.count(
          //网格列数
          crossAxisCount: 3,
          //网格间列的间隙
          crossAxisSpacing: 2.0,
          //内边距
          //padding: const EdgeInsets.all(80.0),
          //网格间上写行的间隙
          mainAxisSpacing: 2.0,
          //宽高比 宽/高
          childAspectRatio: 0.7,
          //内部子元素
          children: <Widget>[
            Image.network(
              'https://ws1.sinaimg.cn/small/0065oQSqly1g0ajj4h6ndj30sg11xdmj.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),
            Image.network(
              'https://ws1.sinaimg.cn/large/0065oQSqly1g04lsmmadlj31221vowz7.jpg',
              fit: BoxFit.cover,
            ),

          ],
        ),
      ),
    );
  }
}
