import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      title: 'Row Widget',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Row Widget'),
        ),
        body: Row(
          children: <Widget>[
            Expanded(
              child: RaisedButton(
                onPressed: () {},
                color: Colors.purple,
                child: Text('按钮一'),
              ),
            ),
            RaisedButton(
              onPressed: () {},
              color: Colors.limeAccent,
              child: Text('按钮二'),
            ),
            Expanded(
              child: RaisedButton(
                onPressed: () {},
                color: Colors.lightBlue,
                child: Text('按钮三'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
