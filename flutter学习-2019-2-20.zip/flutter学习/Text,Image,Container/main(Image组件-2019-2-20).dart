import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hello Flutter Demo',
      home: Scaffold(
        body: Center(
            child: Container(
          child: new Image.network(
            'https://ws1.sinaimg.cn/small/0065oQSqly1fymj13tnjmj30r60zf79k.jpg',
            scale: 1.0,
            fit: BoxFit.scaleDown,
            //fit的方式
            color: Colors.limeAccent,
            //混合模式的颜色
            colorBlendMode: BlendMode.darken,
            //colorBlendMode是混合模式
            repeat: ImageRepeat.repeatX,
            //重复方式
          ),
          width: 500,
          height: 500,
          color: Colors.lightBlue,
        )),
      ),
    );
  }
}
