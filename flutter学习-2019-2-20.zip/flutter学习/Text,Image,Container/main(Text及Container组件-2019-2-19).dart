import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hello Flutter Demo',
      home: Scaffold(
        body: Center(
            child: Container(
          child: new Text(
            'Hello wdl', // 文本内容
            style: TextStyle(
              color: Colors.red,
              fontSize: 23.0,
              decoration: TextDecoration.underline,
              //下划线
              decorationStyle: TextDecorationStyle.solid,
              wordSpacing: 1.0,
            ),
          ),
          alignment: Alignment.topLeft,
          //内部子内容对齐方式
          width: 300.0,
          //宽
          height: 200.0,
          //高
          //color: Colors.cyan,
          //颜色
          //padding: const EdgeInsets.all(10.0), //上下左右的内边距全为10
          padding: const EdgeInsets.fromLTRB(10.0, 20.0, 10.0, 10.0),
          //上下左右的内边距
          margin: const EdgeInsets.fromLTRB(20.0, 10.0, 0.0, 0.0),
          //外边距，Container与外边的距离
          decoration: new BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.lightBlue,
                Colors.greenAccent,
                Colors.purple
              ]),
              //设置渐变，与color冲突
              border: Border.all(
                width: 3.0,
                color: Colors.black,
              ),
              //设置边框
              borderRadius: BorderRadius.all(Radius.circular(10.0))
              //设置边框圆角
              ),
        )),

      ),

    );
  }
}
